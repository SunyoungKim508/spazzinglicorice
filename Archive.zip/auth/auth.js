module.exports = {
  'facebookAuth' : {
    'clientID'      : '1637653006488678', // App ID
    'clientSecret'  : '18d6b88b531d08138ace0891441e097d', // your App Secret
    // 'callbackURL'   : 'http://devslate.elasticbeanstalk.com/auth/facebook/callback'
    'callbackURL'   : 'http://localhost:8080/auth/facebook/callback'
  }
};
