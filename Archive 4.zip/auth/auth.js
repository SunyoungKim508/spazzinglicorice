module.exports = {
  'facebookAuth' : {
    'clientID'      : '110435645991298', // your App ID
    'clientSecret'  : '2a161eb40926e84501f67c392f4e9188', // your App Secret
    'callbackURL'   : 'http://devslate.elasticbeanstalk.com/auth/facebook/callback'
    // 'callbackURL'   : 'http://localhost:8080/auth/facebook/callback'
  }
};
