angular.module('devslate.splash', [])

.controller('SplashCtrl', function ($scope, $stateParams) {

});
